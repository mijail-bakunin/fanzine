import editions from '../data/editions.json';
import EditionCard from '../components/EditionCard';
import { ArrowLink, Paper, SectionTitle, Stamp } from '../components/ui';
export default function Home(){const latest=editions[0]; return <>
  <section className="cover"><div className="cover__edition">{latest.number} · {latest.date}</div><div className="cover__star">✶</div><p className="cover__kicker">Una revista para la rabia, el deseo y la organización</p><h1>LA<br/><span>GUILLOTINA</span></h1><div className="cover__bottom"><Stamp>Nueva edición</Stamp><p>Que caigan los altares.<br/>Que crezcan las redes.</p><ArrowLink to={`/edicion/${latest.slug}`}>Leer la edición</ArrowLink></div></section>
  <Paper className="editorial"><SectionTitle eyebrow="01 / EDITORIAL"/><div className="editorial__grid"><h2>Escribir es<br/><em>hacer lugar.</em></h2><div><p className="lead">No venimos a explicar el mundo desde arriba. Venimos a abrir una página, ensuciarla de preguntas y ponerla a circular.</p><p>La Guillotina es un espacio de pensamiento sin permiso: de barrios, talleres, bibliotecas y plazas. Una publicación para leer despacio, discutir fuerte y pasar de mano en mano.</p><ArrowLink to="/quienes-somos">Conocé el proyecto</ArrowLink></div></div></Paper>
  <section className="latest"><SectionTitle eyebrow="02 / EN ESTA EDICIÓN"/><EditionCard edition={latest} featured/></section>
  <Paper className="manifesto-call"><div><p className="rubric">MANIFIESTO</p><h2>Nadie nos representa.<br/><em>Nos organizamos.</em></h2></div><ArrowLink to="/manifiesto">Leer el manifiesto</ArrowLink></Paper>
  <section className="join"><p>¿Tenés algo que decir?</p><h2>Esta revista<br/>también es tuya.</h2><ArrowLink to="/colaborar">Mandar una colaboración</ArrowLink></section>
</>}
